AFRAME.registerComponent('drag-rotate-component',{
    schema : { speed : {default:1}},
    init : function(){
      this.ifMouseDown = false;
      this.x_cord = 0;
      this.y_cord = 0;
      document.addEventListener('mousedown',this.OnDocumentMouseDown.bind(this));
      document.addEventListener('mouseup',this.OnDocumentMouseUp.bind(this));
      document.addEventListener('mousemove',this.OnDocumentMouseMove.bind(this));
    },
    OnDocumentMouseDown : function(event){
      this.ifMouseDown = true;
      this.x_cord = event.clientX;
      this.y_cord = event.clientY;
    },
    OnDocumentMouseUp : function(){
      this.ifMouseDown = false;
    },
    OnDocumentMouseMove : function(event)
    {
      if(this.ifMouseDown)
      {
        var temp_x = event.clientX-this.x_cord;
        var temp_y = event.clientY-this.y_cord;
        if(Math.abs(temp_y)<Math.abs(temp_x))
        {
          this.el.object3D.rotateY(temp_x*this.data.speed/100);
        }
        else
        {
          this.el.object3D.rotateX(temp_y*this.data.speed/100);
        }
        this.x_cord = event.clientX;
        this.y_cord = event.clientY;
      }
    }
  });

  AFRAME.registerComponent("click-log-coordinates", {
      init: function () {
      this.el.addEventListener("click", (event) => {
          const clickedPosition1 = event.detail.intersection.point;
          const clickedPosition = event.detail.intersection.point.clone().sub(this.el.object3D.position).divideScalar(this.el.object3D.scale.x);
          //console.log("Clicked coordinates on the globe:", clickedPosition);
          //console.log("Clicked coordinates on the globe:", clickedPosition1);
      });
      },
  });

  let click=0;
  AFRAME.registerComponent("click-to-zoom", {
      schema: {
       siteName: { type: "string" },
      },
      init: function () {
          this.el.addEventListener("click", () => {
              click = click+1
              const globe = document.querySelector("#globe");
              const site1 = document.getElementById('germany_text');
              const current = document.getElementById('current');
              const enrollment_summary = document.getElementById('enrollment_summary');
              const subject_summary = document.getElementById('subject_summary');
              const potential_major_pds = document.getElementById('open_potential_major_pds');
              const open_minor_pds = document.getElementById('open_minor_pds');
              const confirmed_major = document.getElementById('open_confirmed_major_pds');
              const open_queries_unanswered = document.getElementById('open_queries_unanswered');
              const pages_entered_intime = document.getElementById('pages_entered_intime');
              const queries_answered_intime = document.getElementById('queries_answered_intime');
              const open_ae = document.getElementById('open_ae');
              const total_ae_count = document.getElementById('total_ae_count');
              const subject_management = document.getElementById('subject_management');
              const protocol_deviation = document.getElementById('protocol_deviation');
              const data_management = document.getElementById('data_management');
              const mypinloc = document.getElementById('mypinlocation');

              if (click%2==1){
                console.log("Hello");
                  globe.setAttribute("animation__zoom", {
                      property: "position",
                      to: `0 10 -3.5`,
                      dur: 1000,
                      easing: "easeInOutQuad",
                  });
                  if (this.el.id == "site_a" || this.el.id =="site_h"){
                    enrollment_summary.setAttribute('charts', {dataPoints: `Data/bar_enrollment_summary.json`});
                    subject_summary.setAttribute('charts', {dataPoints: `Data/bar_subject_summary.json`})
                    potential_major_pds.setAttribute('charts', {dataPoints: `Data/open_potential_major_pds.json`})
                    open_minor_pds.setAttribute('charts', {dataPoints: `Data/open_minor_pds.json`})
                    confirmed_major.setAttribute('charts', {dataPoints: `Data/open_confirmed_major_pds.json`})
                    open_queries_unanswered.setAttribute('charts', {dataPoints: `Data/open_queries_unanswered.json`})
                    pages_entered_intime.setAttribute('charts', {dataPoints: `Data/pages_entered_intime.json`})
                    queries_answered_intime.setAttribute('charts', {dataPoints: `Data/queries_answered_intime.json`})
                    open_ae.setAttribute('charts', {dataPoints: `Data/open_ae.json`})
                    total_ae_count.setAttribute('charts', {dataPoints: `Data/total_ae_count.json`})
                    enrollment_summary.setAttribute('position', {x: -6.5, y: 11, z: -4})
                    subject_summary.setAttribute('position', {x: -4.5, y: 11, z: -4})
                    potential_major_pds.setAttribute('position', {x: -4, y: 8, z: -4})
                    open_minor_pds.setAttribute('position', {x: -6, y: 8, z: -4})
                    confirmed_major.setAttribute('position', {x: -8, y: 8, z: -4})
                    open_queries_unanswered.setAttribute('position', {x: 3.5, y: 8, z: -4})
                    pages_entered_intime.setAttribute('position', {x: 7.5, y:7.8, z: -4})
                    queries_answered_intime.setAttribute('position', {x: 5.5, y: 7.8, z: -4})
                    open_ae.setAttribute('position', {x: 5, y: 11, z: -4})
                    total_ae_count.setAttribute('position', {x: 3, y: 11, z: -4})
                    subject_management.setAttribute('position', {x: -7, y: 14, z: -4})
                    protocol_deviation.setAttribute('position', {x: -9, y: 10.5, z: -4})
                    data_management.setAttribute('position', {x: 2, y: 14, z: -4});
                  }
                  else if(this.el.id == "site_g"){
                    enrollment_summary.setAttribute('charts', {dataPoints: `Data/bar_enrollment_summary_g.json`});
                    subject_summary.setAttribute('charts', {dataPoints: `Data/bar_subject_summary_g.json`})
                    potential_major_pds.setAttribute('charts', {dataPoints: `Data/open_potential_major_pds_g.json`})
                    open_minor_pds.setAttribute('charts', {dataPoints: `Data/open_minor_pds_g.json`})
                    confirmed_major.setAttribute('charts', {dataPoints: `Data/open_confirmed_major_pds_g.json`})
                    open_queries_unanswered.setAttribute('charts', {dataPoints: `Data/open_queries_unanswered_g.json`})
                    pages_entered_intime.setAttribute('charts', {dataPoints: `Data/pages_entered_intime_g.json`})
                    queries_answered_intime.setAttribute('charts', {dataPoints: `Data/queries_answered_intime_g.json`})
                    open_ae.setAttribute('charts', {dataPoints: `Data/open_ae_g.json`})
                    total_ae_count.setAttribute('charts', {dataPoints: `Data/total_ae_count_g.json`})
                    enrollment_summary.setAttribute('position', {x: -6.5, y: 11, z: -4})
                    subject_summary.setAttribute('position', {x: -4.5, y: 11, z: -4})
                    potential_major_pds.setAttribute('position', {x: -4, y: 8, z: -4})
                    open_minor_pds.setAttribute('position', {x: -6, y: 8, z: -4})
                    confirmed_major.setAttribute('position', {x: -8, y: 8, z: -4})
                    open_queries_unanswered.setAttribute('position', {x: 3.5, y: 8, z: -4})
                    pages_entered_intime.setAttribute('position', {x: 7.5, y:7.8, z: -4})
                    queries_answered_intime.setAttribute('position', {x: 5.5, y: 7.8, z: -4})
                    open_ae.setAttribute('position', {x: 5, y: 11, z: -4})
                    total_ae_count.setAttribute('position', {x: 3, y: 11, z: -4})
                    subject_management.setAttribute('position', {x: -7, y: 14, z: -4})
                    protocol_deviation.setAttribute('position', {x: -9, y: 10.5, z: -4})
                    data_management.setAttribute('position', {x: 2, y: 14, z: -4})
                  }

                  x1 = this.el.getAttribute('position').x;
                  y1 = this.el.getAttribute('position').y;
                  z1 = this.el.getAttribute('position').z;
                  r1 = this.el.getAttribute("rotation").x;
                  r2 = this.el.getAttribute("rotation").y;
                  r3 = this.el.getAttribute("rotation").z;

                  
                  value = this.el.getAttribute('data-site-name')
                  site1.setAttribute('value', value);
                  console.log(x1, y1, z1);
                  site1.setAttribute('position', {x: x1+0.17, y: y1+0.3, z: z1+0.21});
                  current.setAttribute('position', {x: x1, y: y1, z: z1+0.01});
                  current.setAttribute('rotation', {x: r1, y: r2, z: r3});
                  console.log("current location", current.getAttribute('position'));
                  mypinloc.setAttribute('position', {x: x1+0.05, y: y1+0.1, z: z1-0.01});
                  mypinloc.setAttribute('rotation', {x: r1, y: r2, z: r3});
                  console.log("pin location",mypinloc.getAttribute('position'));
              }else{
                  site1.setAttribute('position', {x: 1000, y: y1+0.1, z: z1+0.11});
                  enrollment_summary.setAttribute('position', {x: -600.5, y: 11, z: -4})
                  subject_summary.setAttribute('position', {x: -400.5, y: 11, z: -4})
                  potential_major_pds.setAttribute('position', {x: -400, y: 8, z: -4})
                  open_minor_pds.setAttribute('position', {x: -600, y: 8, z: -4})
                  confirmed_major.setAttribute('position', {x: -800, y: 8, z: -4})
                  open_queries_unanswered.setAttribute('position', {x: 300.5, y: 8, z: -4})
                  pages_entered_intime.setAttribute('position', {x: 700.5, y:7.8, z: -4})
                  queries_answered_intime.setAttribute('position', {x: 500.5, y: 7.8, z: -4})
                  open_ae.setAttribute('position', {x: 500, y: 11, z: -4})
                  total_ae_count.setAttribute('position', {x: 300, y: 11, z: -4})
                  subject_management.setAttribute('position', {x: -700, y: 14, z: -4})
                  protocol_deviation.setAttribute('position', {x: -900, y: 10.5, z: -4})
                  data_management.setAttribute('position', {x: 200, y: 14, z: -4})
                  current.setAttribute('position', {x: 1000, y: y1, z: z1+0.01});
                  mypinloc.setAttribute('position', {x: 1000, y: y1, z: z1+0.01});
                  globe.setAttribute("animation__zoom", {
                      property: "position",
                      to: `0 10.5 -5`,
                      dur: 1000,
                      easing: "easeInOutQuad",
                  });
              }
          
       });
      },
   });