! function(t) {
    var e = {};
    var mybarid = -1;

    function i(n) {
        if (e[n]) return e[n].exports;
        var o = e[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return t[n].call(o.exports, o, o.exports, i), o.l = !0, o.exports
    }
    i.m = t, i.c = e, i.d = function(t, e, n) {
        i.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: n
        })
    }, i.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }, i.t = function(t, e) {
        if (1 & e && (t = i(t)), 8 & e) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var n = Object.create(null);
        if (i.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: t
            }), 2 & e && "string" != typeof t)
            for (var o in t) i.d(n, o, function(e) {
                return t[e]
            }.bind(null, o));
        return n
    }, i.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t.default
        } : function() {
            return t
        };
        return i.d(e, "a", e), e
    }, i.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, i.p = "", i(i.s = 0)
}([function(t, e) {
    if ("undefined" == typeof AFRAME) throw new Error("Component attempted to register before AFRAME was available.");

    function i(t) {
        let e = {
            x: 0,
            y: 0,
            z: 0
        };
        if (null == t.attributes.position) return e;
        let i = t.attributes.position.value.split(" ");
        return "" !== i[0] && null != i[0] && (e.x = i[0]), "" !== i[1] && null != i[1] && (e.y = i[1]), "" !== i[2] && null != i[2] && (e.z = i[2]), e
    }

    //Bar popup window modifications
    function n(t, e, barheight, totaldata) {
        //console.log(t.title,"t");
        let mystr = totaldata.toString();
        //console.log(typeof(mystr));
        let i = 0;
        "bar" !== e.type && "cylinder" !== e.type || (i = t.size / 2);
        let n = t.label + ": " + t.y,
            o = 4;
        n.length > 30 && (o = n.length / 8);
        let r = document.createElement("a-plane");
        return r.setAttribute("position", {
            x: t.x + i,
            y: Number(barheight) + 3,
            z: t.z + 0.8
        // }), r.setAttribute("height", "3") ,r.setAttribute("width", o), r.setAttribute("color", "white"), r.setAttribute("text", {
        //     value: "Therapeutic Area \n\n" + n +"\n\n Total Protocols : "+ mystr + "\n\n Percentage : " + (barheight*10).toFixed(2).toString(),
        //     align: "center",
        //     width: 7,
        //     color: "black"
        // }), r.setAttribute("light", {
        }), r.setAttribute("height", "3") ,r.setAttribute("width", o), r.setAttribute("color", "white"), r.setAttribute("text", {
            value:  t.title + "\n\n" + n +"\n\n Total Count : "+ mystr + "\n\n Percentage : " + ((t.y/totaldata)*100).toFixed(2).toString(),
            align: "center",
            width: 7,
            color: "black"
        }), r.setAttribute("light", {
            intensity: .1
        }), r 
    }

    function o(t, e, i) {
        let n = "",
            o = t.slice(),
            r = o.indexOf(e);
        o.splice(r, 1);
        for (let t = 0; t < o.length; t++) "pie" === i.type ? n += o[t].label + ": " + o[t].size : n += o[t].label + ": " + o[t].y, t !== o.length - 1 && (n += "\n");
        return n
    }

    function r(t, e, i) {
        let n = "";
        n = "pie" === i.type ? e.size : e.y;
        let o = document.createElement("a-plane");
        return o.setAttribute("position", t.position_sel_text), o.setAttribute("rotation", t.rotation), o.setAttribute("height", "0.8"), o.setAttribute("width", t.width+1), o.setAttribute("color", "white"), o.setAttribute("text__title", {
            value: e.label + ": " + n,
            align: "center",
            width: "8",
            color: e.color
        }), o.setAttribute("light", {
            intensity: "0"
        }), o
    }

    function l(t, e) {
        let i = document.createElement("a-plane");
        if(e){
            return i.setAttribute("position", t.position_all_text), i.setAttribute("rotation", t.rotation), i.setAttribute("height", t.height+1), i.setAttribute("width", t.width+1), i.setAttribute("color", "white"), i.setAttribute("text__title", {
                value: e,
                align: "center",
                width: "8",
                color: "black"
            }), i.setAttribute("light", {
                intensity: "0.1"
            }), i
        }else{
            return i.setAttribute('height', 0), i.setAttribute('width', 0), i
        }
        
    }

    function a(t, e, i, n, cid) {
        let o = document.createElement("a-cylinder");
        return o.setAttribute("color", t.color), o.setAttribute("c_id", cid), o.setAttribute("theta-start", e), o.setAttribute("theta-length", i), o.setAttribute("side", "double"), o.setAttribute("radius", n), o
    }

    function s(t, e, i, n, tid) {
        let o = document.createElement("a-torus");
        return o.setAttribute("color", t.color), o.setAttribute("rotation", {
            x: 90,
            y: 0,
            z: e
        }), o.setAttribute("arc", i), o.setAttribute("t_id", tid), o.setAttribute("side", "double"), o.setAttribute("radius", n), o.setAttribute("radius-tubular", n / 4), o
    }

    function u(t) {
        let e = document.createElement("a-sphere");
        return e.setAttribute("position", {
            x: t.x,
            y: t.y,
            z: t.z
        }), e.setAttribute("color", t.color), e.setAttribute("radius", t.size), e
    }

    function d(t) {
        let e = document.createElement("a-box");
        return e.setAttribute("position", {
            x: t.x + t.size / 2,
            y: t.y / 2,
            z: t.z
        }), e.setAttribute("color", t.color), e.setAttribute("height", t.y), e.setAttribute("depth", t.size), e.setAttribute("width", t.size), e
    }

    function c(t, myid, bartotaldata, maxval) {
        //let yval = (t.y/bartotaldata)*10;
        let add = maxval/10;
        let yval = t.y/add;
        //console.log(yval, t.y, bartotaldata);
        let e = document.createElement("a-cylinder");
        console.log(t, 't');
        // return e.setAttribute("position", {
        //     x: t.x + t.size / 2,
        //     y: yval / 2,
        //     z: t.z
        // }), e.setAttribute('percentile', yval), e.setAttribute("bar_id", myid) , e.setAttribute("color", t.color), e.setAttribute("height", yval), e.setAttribute("radius", t.size / 2), e
        return e.setAttribute("position", {
            x: t.x + t.size / 2,
            y: yval / 2,
            z: t.z
        }), e.setAttribute('percentile', yval), e.setAttribute("bar_id", myid) , e.setAttribute("color", t.color), e.setAttribute("height", yval), e.setAttribute("radius", t.size / 2), e
    }

    function x(t, e, i) {
        let n = document.createElement("a-plane");
        return n.setAttribute("position", t.position), n.setAttribute("scale", {
            x: 1,
            y: 1,
            z: .01
        }), n.setAttribute("height", "0.5"), n.setAttribute("width", t.width), n.setAttribute("text__title", {
            value: t.name,
            align: "center",
            width: "8",
            color: "black"
        }), n.addEventListener("click", function() {
            let t = e.split(",");
            for (let e of t) {
                let t = document.getElementById(e),
                    n = t.getAttribute("charts");
                n.dataPoints = i, t.setAttribute("charts", n)
            }
        }), n
    }

    function align(odata) {
        const rs1 = document.getElementById('ta');
        const rs2 = document.getElementById('compound');
        const rs3 = document.getElementById('indication');
        const rs4 = document.getElementById('phase');
        const rs5 = document.getElementById('protocol');
        const rs6 = document.getElementById('region');
        const rs7 = document.getElementById('country');
        const rs8 = document.getElementById('site');
        if(odata[0]["TA"] == undefined){
            
        }else{
            rs1.setAttribute("text", {
                value: "TA Count \n\n "+ odata[0]["TA"],
                align: "center",
                width: 3,
                color: "black"
            }), rs1.setAttribute("width",1.3), rs1.setAttribute("height", 0.6);
        }
        if(odata[0]["Compound"] == undefined){
            
        }else{
            rs2.setAttribute("text", {
                value: "Compound Count \n\n "+ odata[0]["Compound"],
                align: "center",
                width: 3,
                color: "black"
            }), rs2.setAttribute("width",1.3), rs2.setAttribute("height", 0.6);
        }
        if(odata[0]["Indication"] == undefined){
            
        }else{
            rs3.setAttribute("text", {
                value: "Indication Count \n\n "+ odata[0]["Indication"],
                align: "center",
                width: 3,
                color: "black"
            }), rs3.setAttribute("width",1.3), rs3.setAttribute("height", 0.6);
        }
        if(odata[0]["Phase"] == undefined){
            
        }else{
            rs4.setAttribute("text", {
                value: "Phase Count \n\n "+ odata[0]["Phase"],
                align: "center",
                width: 3,
                color: "black"
            }), rs4.setAttribute("width",1.3), rs4.setAttribute("height", 0.6);
        }
        if(odata[0]["Protocol"] == undefined){
            
        }else{
            rs5.setAttribute("text", {
                value: "Protocol Count \n\n "+ odata[0]["Protocol"],
                align: "center",
                width: 3,
                color: "black"
            }), rs5.setAttribute("width",1.3), rs5.setAttribute("height", 0.6);
        }
        if(odata[0]["Region"] == undefined){
            
        }else{
            rs6.setAttribute("text", {
                value: "Region Count \n\n "+ odata[0]["Region"],
                align: "center",
                width: 3,
                color: "black"
            }), rs6.setAttribute("width",1.3), rs6.setAttribute("height", 0.6);
        }
        if(odata[0]["Country"] == undefined){
            
        }else{
            rs7.setAttribute("text", {
                value: "Country Count \n\n "+ odata[0]["Country"],
                align: "center",
                width: 3,
                color: "black"
            }), rs7.setAttribute("width",1.3), rs7.setAttribute("height", 0.6);
        }
        if(odata[0]["Site"] == undefined){
            
        }else{
            rs8.setAttribute("text", {
                value: "Site Count \n\n "+ odata[0]["Site"],
                align: "center",
                width: 3,
                color: "black"
            }), rs8.setAttribute("width",1.3), rs8.setAttribute("height", 0.6);
        }
        
    }

    AFRAME.registerComponent("charts", {
        schema: {
            type: {
                type: "string",
                default: "bubble"
            },
            dataPoints: {
                type: "asset"
            },
            axis_visible: {
                type: "boolean",
                default: !0
            },
            axis_position: {
                type: "vec3",
                default: {
                    x: 0,
                    y: 0,
                    z: 0
                }
            },
            axis_color: {
                type: "string",
                default: "red"
            },
            axis_length: {
                type: "number",
                default: 0
            },
            axis_tick_separation: {
                type: "number",
                default: 1
            },
            axis_tick_length: {
                type: "number",
                default: .2
            },
            axis_tick_color: {
                type: "string",
                default: "red"
            },
            axis_negative: {
                type: "boolean",
                default: !0
            },
            axis_grid: {
                type: "boolean",
                default: !1
            },
            axis_grid_3D: {
                type: "boolean",
                default: !1
            },
            axis_text: {
                type: "boolean",
                default: !0
            },
            axis_text_color: {
                type: "string",
                default: "white"
            },
            axis_text_size: {
                type: "number",
                default: 10
            },
            pie_radius: {
                type: "number",
                default: 1
            },
            pie_doughnut: {
                type: "boolean",
                default: !1
            },
            show_popup_info: {
                type: "boolean",
                default: !1
            },
            show_legend_info: {
                type: "boolean",
                default: !1
            },
            show_legend_position: {
                type: "vec3",
                default: {
                    x: 0,
                    y: 0,
                    z: 0
                }
            },
            show_legend_rotation: {
                type: "vec3",
                default: {
                    x: 0,
                    y: 0,
                    z: 0
                }
            },
            show_legend_title: {
                type: "string",
                default: "Global Regions"
            },
            entity_id_list: {
                type: "string",
                default: ""
            },
            dataPoints_list: {
                type: "string",
                default: ""
            }
        },
        multiple: !1,
        init: function() {
            this.loader = new THREE.FileLoader
        },
        update: function(t) {
            const e = this.data;
            //console.log(e.dataPoints);
            if (e.dataPoints && e.dataPoints !== t.dataPoints)
                for (; this.el.firstChild;) this.el.firstChild.remove();
            if (e.dataPoints) {
                if (e.dataPoints.constructor === [{}].constructor) this.onDataLoaded(this, e.dataPoints, !0);
                else if (e.dataPoints.constructor === "".constructor) try {
                    this.onDataLoaded(this, JSON.parse(e.dataPoints), !0)
                } catch (t) {
                    this.loader.load(e.dataPoints, this.onDataLoaded.bind(this, !1))
                }
            } else "totem" === e.type && function(t, e) {
                if ("" === t.dataPoints_list) return;
                let n = t.dataPoints_list.constructor === {}.constructor ? t.dataPoints_list : JSON.parse(t.dataPoints_list.replace(/'/g, '"')),
                    o = i(e),
                    r = function(t) {
                        let e = "Select dataSource:".length;
                        for (let i in t) i.length > e && (e = i.length);
                        let i = 2;
                        e > 9 && (i = e / 4.4);
                        return i
                    }(n);
                e.appendChild(function(t, e) {
                    let i = document.createElement("a-plane");
                    return i.setAttribute("position", e), i.setAttribute("scale", {
                        x: 1,
                        y: 1,
                        z: .01
                    }), i.setAttribute("height", "0.5"), i.setAttribute("color", "blue"), i.setAttribute("width", t), i.setAttribute("text__title", {
                        value: "Select dataSource:",
                        align: "center",
                        width: "9",
                        color: "white"
                    }), i
                }(r, o));
                let l = .75;
                for (let i in n) {
                    let a = {};
                    a.position = {
                        x: o.x,
                        y: parseInt(o.y) - l,
                        z: o.z
                    }, a.name = i, a.width = r, e.appendChild(x(a, t.entity_id_list, n[i])), l += .65
                }
            }(e, this.el)
        },
        remove: function() {},
        pause: function() {},
        play: function() {},
        onDataLoaded: function(t, e) {
            let x = e;
            try {
                t || (x = JSON.parse(e))
            } catch (t) {
                throw new Error("Can't parse JSON file. Maybe is not a valid JSON file")
            }
            //console.log(x);
            align(x);
            //console.log(x[0].label);
            const y = this.data;
            let _, p = this.el;
            ! function(t, e, i) {
                if (!e.axis_visible || "pie" === e.type) return;
                if (0 === e.axis_length) {
                    let t = function(t) {
                        let e = 0,
                            i = !1;
                        for (let n of t) {
                            (n.x < 0 || n.y < 0 || n.z < 0) && (i = !0);
                            let t = Math.abs(n.x),
                                o = Math.abs(n.y),
                                r = Math.abs(n.z);
                            t > e && (e = t), o > e && (e = o), r > e && (e = r)
                        }
                        return {
                            max: e,
                            has_negative: i
                        }
                    }(i);
                    e.axis_length = t.max, e.axis_negative && (e.axis_negative = t.has_negative)
                }
                e.axis_grid || e.axis_grid_3D ? function(t, e) {
                    let i = e.axis_length,
                        n = e.axis_position,
                        o = e.axis_color,
                        r = e.axis_negative,
                        l = 0,
                        a = 0,
                        s = e.axis_grid_3D,
                        u = e.axis_text,
                        d = e.axis_text_color,
                        c = e.axis_text_size;
                    for (let e of ["x", "y", "z"]) {
                        let x = {
                            x: n.x,
                            y: n.y,
                            z: n.z
                        };
                        x[e] = i + n[e];
                        let y = {
                            x: n.x,
                            y: n.y,
                            z: n.z
                        };
                        r && (l = i, a = i + 1, y[e] = -i + n[e]);
                        let _ = document.createElement("a-entity");
                        _.setAttribute("line__" + e, {
                            start: y,
                            end: x,
                            color: o
                        });
                        for (let r = 1 - a; r <= i; r++) {
                            let a, x, y, p;
                            if ("x" === e ? (a = {
                                    x: n.x + r,
                                    y: n.y - l,
                                    z: n.z
                                }, x = {
                                    x: n.x + r,
                                    y: n.y + i,
                                    z: n.z
                                }, y = {
                                    x: n.x + r,
                                    y: n.y,
                                    z: n.z - l
                                }, p = {
                                    x: n.x + r,
                                    y: n.y,
                                    z: n.z + i
                                }) : "y" === e ? (a = {
                                    x: n.x,
                                    y: n.y + r,
                                    z: n.z - l
                                }, x = {
                                    x: n.x,
                                    y: n.y + r,
                                    z: n.z + i
                                }, y = {
                                    x: n.x - l,
                                    y: n.y + r,
                                    z: n.z
                                }, p = {
                                    x: n.x + i,
                                    y: n.y + r,
                                    z: n.z
                                }) : (a = {
                                    x: n.x - l,
                                    y: n.y,
                                    z: n.z + r
                                }, x = {
                                    x: n.x + i,
                                    y: n.y,
                                    z: n.z + r
                                }, y = {
                                    x: n.x,
                                    y: n.y - l,
                                    z: n.z + r
                                }, p = {
                                    x: n.x,
                                    y: n.y + i,
                                    z: n.z + r
                                }), u) {
                                let i = document.createElement("a-text");
                                i.setAttribute("position", x), "x" === e ? i.setAttribute("text__" + e + r, {
                                    value: Math.round(100 * r) / 100,
                                    width: c,
                                    color: d,
                                    xOffset: 5
                                }) : "y" === e ? i.setAttribute("text__" + e + r, {
                                    value: Math.round(100 * r) / 100,
                                    width: c,
                                    color: d,
                                    xOffset: 4
                                }) : i.setAttribute("text__" + e + r, {
                                    value: Math.round(100 * r) / 100,
                                    width: c,
                                    color: d,
                                    xOffset: 4.5
                                }), t.appendChild(i)
                            }
                            if (_.setAttribute("line__" + e + r, {
                                    start: a,
                                    end: x,
                                    color: o
                                }), _.setAttribute("line__" + e + r + i, {
                                    start: y,
                                    end: p,
                                    color: o
                                }), s)
                                for (let t = 1 - l; t <= i; t++) {
                                    let a, s;
                                    "x" === e ? (a = {
                                        x: n.x + r,
                                        y: n.y - l,
                                        z: n.z + t
                                    }, s = {
                                        x: n.x + r,
                                        y: n.y + i,
                                        z: n.z + t
                                    }) : "y" === e ? (a = {
                                        x: n.x + t,
                                        y: n.y + r,
                                        z: n.z - l
                                    }, s = {
                                        x: n.x + t,
                                        y: n.y + r,
                                        z: n.z + i
                                    }) : (a = {
                                        x: n.x - l,
                                        y: n.y + t,
                                        z: n.z + r
                                    }, s = {
                                        x: n.x + i,
                                        y: n.y + t,
                                        z: n.z + r
                                    }), _.setAttribute("line__" + e + r + t + i, {
                                        start: a,
                                        end: s,
                                        color: o
                                    })
                                }
                        }
                        t.appendChild(_)
                    }
                }
                (t, e, z) : function(t, e, z) {
                    //console.log('z', z);
                    //console.log(t.getElementsByTagName('a-cylinder'));
                    let i = e.axis_length,
                        n = e.axis_position,
                        o = e.axis_color,
                        r = e.axis_tick_separation,
                        l = e.axis_tick_length,
                        a = e.axis_tick_color,
                        s = e.axis_negative,
                        u = 0,
                        d = e.axis_text,
                        c = e.axis_text_color,
                        x = e.axis_text_size;
                    //for (let e of ["x", "y", "z"]) {
                    for (let e of ["x", "y"]) {
                        let y = {
                            x: n.x,
                            y: n.y,
                            z: n.z + 0.5
                        };
                        y[e] = i + n[e];
                        let _ = {
                            x: n.x,
                            y: n.y,
                            z: n.z + 0.5
                        };
                        s && (u = i + 1, _[e] = -i + n[e]);
                        let p = document.createElement("a-entity");
                        //console.log(10,10);
                        y.x !== 0 ? y.x=z.length : 0;
                        y.y !== 0 ? y.y=10 : 0;
                        //console.log(y);
                        p.setAttribute("line__" + e, {
                            start: _,
                            end: y,
                            color: o
                        });
                        index = 10;
                        let ind = i/10;
                        let add = i/10;
                        //console.log('i', i);
                        //console.log('r-u', r-u);
                        //console.log('r',r);
                        let xtick = 0;
                        let xtick1 = 0;
                        //console.log(i);
                        //console.log(r-u);
                        for (let o = r - u; o <= i; o += r) {
                            //console.log(r, u, r-u, i);
                            let i, r;
                            xtick += 1;
                            if (index < 101){
                                if ( "x" === e ? (xtick < z.length+1) ? (i = {
                                        x: n.x + o,
                                        y: n.y - l,
                                        z: n.z + 0.5
                                    }, r = {
                                        x: n.x + o,
                                        y: n.y + l,
                                        z: n.z + 0.5
                                    }): 0 : "y" === e ? (i = {
                                        x: n.x,
                                        y: n.y + o,
                                        z: n.z - l + 0.45
                                    }, r = {
                                        x: n.x,
                                        y: n.y + o,
                                        z: n.z + l + 0.5
                                    }) : (i = {
                                        x: n.x - l,
                                        y: n.y,
                                        z: n.z + o
                                    }, r = {
                                        x: n.x + l,
                                        y: n.y,
                                        z: n.z + o
                                    }) , p.setAttribute("line__" + e + o, {
                                        start: i,
                                        end: r,
                                        color: a
                                    }), d) {
                                    
                                    let n = document.createElement("a-text");
                                    let xprevpos = 0;
                                    //console.log('xtick1',xtick1);
                                    if(xtick1 < z.length){
                                        xprevpos=i.x;
                                    }
                                    n.setAttribute("position", i), "x" === e ? xtick1 < z.length ? n.setAttribute("text__" + e + o, {
                                        value: z[xtick1].label,
                                        width: x+1,
                                        color: "black",
                                        xOffset: 5
                                    })&n.setAttribute("rotation",{
                                        x: 0,
                                        y: 0,
                                        z: 90 
                                    }) & n.setAttribute("position",{
                                        x: xprevpos-0.3,
                                        y: 0.6,
                                    }) : 0 : "y" === e ? n.setAttribute("text__" + e + o, {
                                        value: Math.floor(ind),
                                        width: x,
                                        color: "white",
                                        xOffset: 4
                                    }) : n.setAttribute("text__" + e + o, {
                                        value: Math.round(100 * o) / 100,
                                        width: x,
                                        color: c,
                                        xOffset: 4.5
                                    }), t.appendChild(n), index=index+10, xtick1++, ind=ind+add;
                                }
                            }
                        }
                        t.appendChild(p)
                    }
                }(t, e, x)
            }(p, y, x);
            //console.log(y);
            let h, f, b, z, g = y.show_popup_info && "pie" !== y.type && !y.pie_doughnut,
                A = y.show_legend_info;
            A && x.length > 0 && (z = function(t, e, n) {
                let o = 2;
                t.length - 1 > 6 && (o = (t.length - 1) / 3);
                let r = e.show_legend_title.length;
                for (let i of t) {
                    let t = i.label + ": ";
                    
                    "pie" === e.type ? t += i.size : t += i.y, t.length > r && (r = t.length)
                }
                let l = 1;
                //console.log(t);
                //console.log(r);
                //r > 9
                r > 2 && (l = r / 6);
                let a = i(n),
                    s = {
                        x: e.show_legend_position.x - a.x ,
                        y: e.show_legend_position.y - a.y + o / 2 + .5 + 1.5,
                        z: e.show_legend_position.z - a.z - 2
                    },
                    u = {
                        x: e.show_legend_position.x - a.x,
                        y: e.show_legend_position.y - a.y + o / 2 + 1.2,
                        z: e.show_legend_position.z - a.z - 2
                    },
                    d = {
                        x: e.show_legend_position.x - a.x,
                        y: e.show_legend_position.y - a.y + 0.2,
                        z: e.show_legend_position.z - a.z - 2
                    },
                    c = function(t) {
                        let e = {
                            x: 0,
                            y: 0,
                            z: 0
                        };
                        if (null == t.attributes.rotation) return e;
                        let i = t.attributes.rotation.value.split(" ");
                        "" !== i[0] && null != i[0] && (e.x = i[0]);
                        "" !== i[1] && null != i[1] && (e.y = i[1]);
                        "" !== i[2] && null != i[2] && (e.z = i[2]);
                        return e
                    }(n),
                    x = {
                        x: e.show_legend_rotation.x - c.x,
                        y: e.show_legend_rotation.y - c.y,
                        z: e.show_legend_rotation.z - c.z
                    };
                    //console.log(s);
                return {
                    height: o,
                    width: l,
                    title: e.show_legend_title,
                    rotation: x,
                    position_tit: s,
                    position_sel_text: u,
                    position_all_text: d
                }
            }(x, y, p), h = function(t) {
                let e = document.createElement("a-plane");
                return e.setAttribute("position", t.position_tit), e.setAttribute("rotation", t.rotation), e.setAttribute("height", "0.6"), e.setAttribute("width", t.width+1), e.setAttribute("color", "white"), e.setAttribute("text__title", {
                    value: t.title,
                    align: "center",
                    width: "10",
                    color: "blue"
                }), e
            }(z), f = r(z, x[0], y), b = l(z, o(x, x[0], y)), p.appendChild(h), p.appendChild(f), p.appendChild(b));
            let m = 0,
                w = 0,
                v = 0;
            let totalbardata = 0;
            maxval = 0
            if ("pie" === y.type)
                for (let t of x) v += t.size;
            else{
                for (let bar of x){
                    totalbardata += bar.y;
                    maxval < bar.y ? maxval=bar.y : 0
                }
            }
            let clc = 0;
            let myid = 1;
            for (let t of x) {
                let e;
                const overview = document.getElementById('overview');
                const elem1 = document.getElementById('global_regions');
                const elem2 = document.getElementById('countries');
                const elem3 = document.getElementById('site_status');
                const elem4 = document.getElementById('phases');
                const elem8 = document.getElementById('protocol_status');
                const elem9 = document.getElementById('country_status');
                const elem5 = document.getElementById('rag_countries');
                const elem6 = document.getElementById('rag_site_id');
                const elem7 = document.getElementById('rag_protocol_id');
                const bar1 = document.getElementById('bar-trend-country');
                const bar2 = document.getElementById('bar-trend-protocol');
                const bar3 = document.getElementById('bar-trend-site');
                
                elem2.setAttribute('legend')
                "bar" === y.type ? e = d(t) : "cylinder" === y.type ? e = c(t, myid, totalbardata, maxval) : "pie" === y.type ? (w = 360 * t.size / v, e = y.pie_doughnut ? s(t, m, w, y.pie_radius, myid) : a(t, m, w, y.pie_radius, myid), m += w) : e = u(t),
                myid += 1;
                //console.log(e);
                e.addEventListener("mousedown", function() {
                    //defining click event only to bar chart
                    /**this.getAttribute('bar_id') == 5 ? elem.setAttribute('charts', {pie_radius: 2, dataPoints: 'Data/pie_data5.json'}):0,
                    (this.getAttribute('bar_id') == 4 ? elem.setAttribute('charts', {pie_radius: 2, dataPoints: 'Data/pie_data4.json'}): 
                    (this.getAttribute('bar_id') == 3 ? elem.setAttribute('charts', {pie_radius: 2, dataPoints: 'Data/pie_data3.json'}): 
                    (this.getAttribute('bar_id') == 2 ? elem.setAttribute('charts', {pie_radius: 2, dataPoints: 'Data/pie_data2.json'}):
                    (this.getAttribute('bar_id') == 1 ? elem.setAttribute('charts', {pie_radius: 2, dataPoints: 'Data/pie_data1.json'}): 0)))),**/
                    //this.getAttribute('height') == 5 ? elem.setAttribute('charts', {pie_radius: 2, dataPoints: 'Data/pie_data1.json'}):0,
                    this.parentElement.id == 'bar-model' ? 
                    (
                        overview.setAttribute('charts', {dataPoints: `Data/overview${this.getAttribute('bar_id')}.json`}),
                        clc % 2==0 ? 
                        elem1.setAttribute('my_bar_id', this.getAttribute('bar_id')) & 
                        elem1.setAttribute('charts', {dataPoints: `Data/pie_data1${this.getAttribute('bar_id')}.json`}) & 
                        elem1.setAttribute('position',{x: 0, y: 2, z: -3.5}) &
                        elem3.setAttribute('charts', {dataPoints: `Data/pie_site_status_data${this.getAttribute('bar_id')}.json`}) &  
                        elem3.setAttribute('position',{x: -3.5, y: 2.2, z: -2.7}) &
                        elem4.setAttribute('charts', {dataPoints: `Data/pie_study_phase_data${this.getAttribute('bar_id')}.json`}) &  
                        elem4.setAttribute('position',{x: -3, y: 0.5, z: -2}) &
                        elem5.setAttribute('charts', {dataPoints: `Data/pie_rag_country_data1${this.getAttribute('bar_id')}.json`}) &  
                        elem5.setAttribute('position',{x: 2, y: 0.5, z: -2}) &
                        elem6.setAttribute('charts', {dataPoints: `Data/pie_rag_site_data1${this.getAttribute('bar_id')}.json`}) &  
                        elem6.setAttribute('position',{x: 4, y: 0.5, z: -2}) &
                        elem7.setAttribute('charts', {dataPoints: `Data/pie_rag_study_data1${this.getAttribute('bar_id')}.json`}) &  
                        elem7.setAttribute('position',{x: 0, y: 0.5, z: -2}) &
                        elem8.setAttribute('charts', {dataPoints: `Data/pie_protocol_status_data${this.getAttribute('bar_id')}.json`}) &  
                        elem8.setAttribute('position',{x: -6, y: 0.5, z: -2}) &
                        elem9.setAttribute('charts', {dataPoints: `Data/pie_country_status_data${this.getAttribute('bar_id')}.json`}) &  
                        elem9.setAttribute('position',{x: -4.5, y: 0.5, z: -2}) &
                        bar1.setAttribute('charts', {dataPoints: `Data/bar_trend_country_data${this.getAttribute('bar_id')}.json`}) &  
                        bar1.setAttribute('position',{x: -5, y: 2.2, z: -2.5}) &
                        bar2.setAttribute('charts', {dataPoints: `Data/bar_trend_protocol_data${this.getAttribute('bar_id')}.json`}) &  
                        bar2.setAttribute('position',{x: -6, y: 2.2, z: -2.5}) &
                        bar3.setAttribute('charts', {dataPoints: `Data/bar_trend_site_data${this.getAttribute('bar_id')}.json`}) &  
                        bar3.setAttribute('position',{x: -7.5, y: 2.2, z: -2.5}) : 
                        elem1.setAttribute('my_bar_id', this.getAttribute('bar_id')) & 
                        elem1.setAttribute('position',{x: 200, y: 0.8, z: -3}) & 
                        elem2.setAttribute('position',{x: 210, y: 0.8, z: -3}) &
                        elem3.setAttribute('position',{x: 220, y: 0.8, z: -3}) &
                        elem4.setAttribute('position',{x: 230, y: 0.8, z: -3}) &
                        elem5.setAttribute('position',{x: 240, y: 0.8, z: -3}) &
                        elem6.setAttribute('position',{x: 240, y: 0.8, z: -3}) &
                        elem7.setAttribute('position',{x: 240, y: 0.8, z: -3}) &
                        elem8.setAttribute('position',{x: 240, y: 0.8, z: -3}) &
                        elem9.setAttribute('position',{x: 240, y: 0.8, z: -3}) &
                        bar1.setAttribute('position',{x: 200, y: 0.9, z: -2}) &
                        bar2.setAttribute('position',{x: 200, y: 0.9, z: -2}) &
                        bar3.setAttribute('position',{x: 200, y: 0.9, z: -2}) &
                        overview.setAttribute('charts', {dataPoints: `Data/overview0.json`})
                    ): 0,

                    this.parentElement.id == 'global_regions'?
                    (
                        (clc % 2==0) ? 
                        elem2.setAttribute('charts', {dataPoints: `Data/pie_data2${elem1.getAttribute('my_bar_id')}${this.getAttribute('c_id')}.json`}) & 
                        elem2.setAttribute('position',{x: 4, y: 2, z: -3.5}) : 
                        elem2.setAttribute('position',{x: 200, y: 0.8, z: -3})
                    ): 0,

                    console.log(this),
                    //console.log(elem1.getAttribute('my_bar_id')),
                    //console.log("2",elem1.getAttribute('my_bar_id'),this.getAttribute('c_id')),
                    clc = clc+1
                    //elem.setAttribute('charts', {pie_radius: 2, dataPoints: 'Data/pie_data2.json'}),
                    //g && (_ = n(t, y), p.appendChild(_)), A && (p.removeChild(f), p.removeChild(b), f = r(z, t, y), b = l(z, o(x, t, y)), p.appendChild(f), p.appendChild(b))
                }), p.appendChild(e),
                e.addEventListener("mouseenter", function() {
                    this.setAttribute("scale", {
                        x: 1.2,
                        y: 1.2,
                        z: 1.2
                    })
                    g && (_ = n(t, y, this.getAttribute('percentile'), totalbardata), p.appendChild(_)), A && (p.removeChild(f), p.removeChild(b), f = r(z, t, y), b = l(z, o(x, t, y)), p.appendChild(f), p.appendChild(b))
                }), e.addEventListener("mouseleave", function() {
                    this.setAttribute("scale", {
                        x: 1,
                        y: 1,
                        z: 1
                    }), g && p.removeChild(_)
                }), p.appendChild(e)
            }
        }
    })
}]);